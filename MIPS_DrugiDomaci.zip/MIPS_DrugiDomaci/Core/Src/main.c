/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

// definisanje izlaznih pinova mikrokontrolera
#define puLM1 GPIO_PIN_1
#define dirM1 GPIO_PIN_2
#define enaM1 GPIO_PIN_3
#define puLM2 GPIO_PIN_4
#define dirM2 GPIO_PIN_5
#define enaM2 GPIO_PIN_6

double korakMotora=1.8;

// definisemo niz sa 11 epruveta
int nizEpruveta[]={2,0,1,1,2,3,1,1,3,0,3};

// definisemo maksimalnu temperaturu do koje treba da se vrti prvi motor
int Temperatura=55;

// definisemo broj koraka motora za jedno okretanje (1.8 stepeni je korak motora)
int brojKoraka=200;

// definisemo broj epruveta
int duzinaNiza=11;

//epruveta do koje zelimo da dodjemo
int potrebnaEpruveta=2;

uint32_t trenutnaPozicijaM1 = 0;

void startM1() {
    HAL_GPIO_WritePin(GPIOA, enaM1, GPIO_PIN_SET); //startujemo motor M1
    HAL_GPIO_WritePin(GPIOA, enaM2, GPIO_PIN_RESET); //inicijalno da je motor M2 ugasen
}

void stopM1() {
    HAL_GPIO_WritePin(GPIOA,enaM1, GPIO_PIN_RESET);//iskljucujemo motor M1
}

void startM2() {
    const float duzina_trake = 50.0;  // Duzina trake u milimetrima
    const float korakMM= 5.0;   // Pomeraj po koraku u milimetrima
    const int impulsObrtaj= 18;   // Broj impulsa (koraka) po obrtaju(360/1,8/11)

    // Broj koraka potreban za pomeranje trake za 50 mm
    int brojKoraka = (int)(duzina_trake / korakMM);

    // Ukupan broj impulsa za pomeranje trake
    int ukupnoImpulsa = brojKoraka * impulsObrtaj;

    // Motor ce biti ukljucen dok epruveta ne prođe traku
    for (int i = 0; i < ukupnoImpulsa; i++) {
        HAL_GPIO_WritePin(GPIOA, enaM2, GPIO_PIN_SET);
        HAL_Delay(10);  // Pauza između impulsa
    }
}

//iskljucujemo motor M2
void stopM2() {
    HAL_GPIO_WritePin(GPIOA, enaM2, GPIO_PIN_RESET);
}



//trazenje najblize pozicije epruvete
void pronadjiPozicijuEpruvete2() {
    uint32_t ciljanaPozicijaEpruvete2 = 2;  // Postavite ciljanu poziciju
    uint32_t trenutnaPozicija = 0;  // Promenljiva za pracenje trenutne pozicije


    for (uint32_t i = 0; i < duzinaNiza; i++) {
        int razlika = ciljanaPozicijaEpruvete2 - trenutnaPozicija;//trazimo razliku izmedju ciljane i trenutne pozicije

        if (nizEpruveta[i] == ciljanaPozicijaEpruvete2) {
            break;
        }

        int koraciLevo = (nizEpruveta[i] - trenutnaPozicija + duzinaNiza) % duzinaNiza; //najkraci put levo
        int koraciDesno = (trenutnaPozicija - nizEpruveta[i] + duzinaNiza) % duzinaNiza; //najkraci put desno

        // racunamo ugao koji jee potreban da bi stigli do odredjene epruvete i okrecemo motor za toliko stepeni zavisno od ispunjenog uslova
        if (koraciLevo < koraciDesno) {
            float ugao = koraciLevo * korakMotora;
            okreniMotorLevo(ugao);
            HAL_Delay(10);
            trenutnaPozicija = nizEpruveta[i];
        }
        else {
            float ugao = koraciDesno * korakMotora;
            okreniMotorDesno(ugao);
            trenutnaPozicija = nizEpruveta[i];
        }
    }
}
void okreniMotorLevo(float ugao) {
    // Provera za korakMotora
    if (korakMotora <= 0) {
        return;
    }
    HAL_GPIO_WritePin(GPIOA, dirM1, GPIO_PIN_SET);//postavljamo pravac okretanja na levo

    // Broj koraka potreban za zadati ugao
    int brojKoraka = (int)(ugao / korakMotora);

    // Pretvaramo brojKoraka u "korake motora" gde pun krug ima 200 koraka(360/1.8(korak motora))
    int koraciMotora = brojKoraka % 200;

    for (int i = 0; i < koraciMotora; i++) {
        HAL_GPIO_WritePin(GPIOA, enaM1, GPIO_PIN_SET);//omogucavamo kretanje motora
        HAL_GPIO_WritePin(GPIOA, puLM1, GPIO_PIN_RESET);// signaliziramo motoru da moze da napravi korak
        HAL_Delay(10);
        HAL_GPIO_WritePin(GPIOA, puLM1, GPIO_PIN_SET);// signalizira motoru da zavrsi korak
        HAL_Delay(10);
    }
}

void okreniMotorDesno(float ugao) {
    // Provera za korakMotora
    if (korakMotora <= 0) {
        return;
    }
    HAL_GPIO_WritePin(GPIOA, dirM1, GPIO_PIN_RESET); //postavljamo pravac okretanja na desno

    // Broj koraka potreban za zadati ugao
    int brojKoraka = (int)(ugao / korakMotora);

    // Pretvaramo brojKoraka u "korake motora" gde pun krug ima 200 koraka(360/1.8)
    int koraciMotora = brojKoraka % 200;

    for (int i = 0; i < koraciMotora; i++) {
        HAL_GPIO_WritePin(GPIOA, enaM1, GPIO_PIN_SET);//omogucavamo kretanje motora
        HAL_GPIO_WritePin(GPIOA, puLM1, GPIO_PIN_SET);// signaliziramo motoru da moze da napravi korak
        HAL_Delay(10);
        HAL_GPIO_WritePin(GPIOA, puLM1, GPIO_PIN_RESET);// signalizira motoru da zavrsi korak
        HAL_Delay(10);
    }
}

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_ADC1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */


  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  /* USER CODE BEGIN 2 */

  float citajTemperaturu() {
      HAL_ADC_Start(&hadc1);  // Startuje konverziju
      HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY);
      uint16_t analogni = HAL_ADC_GetValue(&hadc1);
      // MCP9701 ima izlaz od 19.5 mV po stepenu Celzijusa, a napon od 500 mV pri 0°C
      float temperatura = (analogni * 0.0195) - 50.0; // Konvertujemo analognu vrednost u digitalnu i prevodimo u stepene celzijusa
      return temperatura; //vracamo temperaturu u stepenima
  }


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

	  // sve dok je ocitana tempertaura manja od definisane motor1 je startovan
	  //u suprotnom kada ocitana vrednost postane veca od definisane motor1 prestaje sa radom
	  // trazimo poziciju epruvete koja ima supstancu broj 2
	  //startujemo motor2 koji ce tu epruvetu transportovati i zatim i motor2 prestaje sa radom
	  if (citajTemperaturu() < Temperatura) {
	            startM1();
	        }
	  else {
	            stopM1();
	            HAL_Delay(500);

	            pronadjiPozicijuEpruvete2();

	            startM2();
	            HAL_Delay(500);
	            stopM2();
	        }

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV2;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4
                          |GPIO_PIN_5|GPIO_PIN_6, GPIO_PIN_RESET);

  /*Configure GPIO pins : PA1 PA2 PA3 PA4
                           PA5 PA6 */
  GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3|GPIO_PIN_4
                          |GPIO_PIN_5|GPIO_PIN_6;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
